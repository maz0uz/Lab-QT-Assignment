/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *ArrayConditionLab;
    QLabel *label_2;
    QPushButton *LinearSearchBut;
    QPushButton *BinarySearchBut;
    QLabel *label_3;
    QLineEdit *ArraySizeEdit;
    QPushButton *GenerateBut;
    QPushButton *MergeSortBut;
    QPushButton *STLSortBut;
    QLineEdit *FindLineEdit;
    QPushButton *FindBut;
    QLabel *InfoLab;
    QLabel *ErrorsLab;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QGridLayout *gridLayout;
    QLabel *ArrayLab;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(800, 453);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        ArrayConditionLab = new QLabel(centralwidget);
        ArrayConditionLab->setObjectName("ArrayConditionLab");
        ArrayConditionLab->setGeometry(QRect(370, 0, 101, 20));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 140, 191, 20));
        LinearSearchBut = new QPushButton(centralwidget);
        LinearSearchBut->setObjectName("LinearSearchBut");
        LinearSearchBut->setGeometry(QRect(40, 180, 101, 29));
        BinarySearchBut = new QPushButton(centralwidget);
        BinarySearchBut->setObjectName("BinarySearchBut");
        BinarySearchBut->setGeometry(QRect(40, 220, 101, 29));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(10, 330, 151, 20));
        ArraySizeEdit = new QLineEdit(centralwidget);
        ArraySizeEdit->setObjectName("ArraySizeEdit");
        ArraySizeEdit->setGeometry(QRect(160, 330, 61, 21));
        GenerateBut = new QPushButton(centralwidget);
        GenerateBut->setObjectName("GenerateBut");
        GenerateBut->setGeometry(QRect(60, 370, 131, 29));
        MergeSortBut = new QPushButton(centralwidget);
        MergeSortBut->setObjectName("MergeSortBut");
        MergeSortBut->setGeometry(QRect(290, 330, 251, 29));
        STLSortBut = new QPushButton(centralwidget);
        STLSortBut->setObjectName("STLSortBut");
        STLSortBut->setGeometry(QRect(290, 370, 251, 29));
        FindLineEdit = new QLineEdit(centralwidget);
        FindLineEdit->setObjectName("FindLineEdit");
        FindLineEdit->setGeometry(QRect(590, 190, 141, 21));
        FindBut = new QPushButton(centralwidget);
        FindBut->setObjectName("FindBut");
        FindBut->setGeometry(QRect(620, 220, 83, 29));
        InfoLab = new QLabel(centralwidget);
        InfoLab->setObjectName("InfoLab");
        InfoLab->setGeometry(QRect(590, 10, 211, 171));
        ErrorsLab = new QLabel(centralwidget);
        ErrorsLab->setObjectName("ErrorsLab");
        ErrorsLab->setGeometry(QRect(580, 270, 221, 41));
        scrollArea = new QScrollArea(centralwidget);
        scrollArea->setObjectName("scrollArea");
        scrollArea->setGeometry(QRect(260, 30, 311, 301));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName("scrollAreaWidgetContents");
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 309, 299));
        gridLayout = new QGridLayout(scrollAreaWidgetContents);
        gridLayout->setObjectName("gridLayout");
        ArrayLab = new QLabel(scrollAreaWidgetContents);
        ArrayLab->setObjectName("ArrayLab");
        ArrayLab->setWordWrap(true);

        gridLayout->addWidget(ArrayLab, 0, 0, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        ArrayConditionLab->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "Choose your search method", nullptr));
        LinearSearchBut->setText(QCoreApplication::translate("MainWindow", "Linear Search", nullptr));
        BinarySearchBut->setText(QCoreApplication::translate("MainWindow", "Binary Search", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Input Dataset Size >>", nullptr));
        GenerateBut->setText(QCoreApplication::translate("MainWindow", "Generate Dataset", nullptr));
        MergeSortBut->setText(QCoreApplication::translate("MainWindow", "Sort Using Merge Sort", nullptr));
        STLSortBut->setText(QCoreApplication::translate("MainWindow", "Sort Using STL Sort", nullptr));
        FindBut->setText(QCoreApplication::translate("MainWindow", "Find it!", nullptr));
        InfoLab->setText(QString());
        ErrorsLab->setText(QString());
        ArrayLab->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
