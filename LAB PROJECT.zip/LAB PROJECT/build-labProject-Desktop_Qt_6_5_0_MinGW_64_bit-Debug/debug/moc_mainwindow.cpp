/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../labProject/mainwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "on_GenerateBut_clicked",
    "",
    "on_LinearSearchBut_clicked",
    "on_BinarySearchBut_clicked",
    "LinearSearch",
    "Num",
    "BinarySearch",
    "mergeSort",
    "p",
    "r",
    "on_FindBut_clicked",
    "merge",
    "q",
    "on_MergeSortBut_clicked",
    "on_STLSortBut_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[32];
    char stringdata0[11];
    char stringdata1[23];
    char stringdata2[1];
    char stringdata3[27];
    char stringdata4[27];
    char stringdata5[13];
    char stringdata6[4];
    char stringdata7[13];
    char stringdata8[10];
    char stringdata9[2];
    char stringdata10[2];
    char stringdata11[19];
    char stringdata12[6];
    char stringdata13[2];
    char stringdata14[24];
    char stringdata15[22];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 22),  // "on_GenerateBut_clicked"
        QT_MOC_LITERAL(34, 0),  // ""
        QT_MOC_LITERAL(35, 26),  // "on_LinearSearchBut_clicked"
        QT_MOC_LITERAL(62, 26),  // "on_BinarySearchBut_clicked"
        QT_MOC_LITERAL(89, 12),  // "LinearSearch"
        QT_MOC_LITERAL(102, 3),  // "Num"
        QT_MOC_LITERAL(106, 12),  // "BinarySearch"
        QT_MOC_LITERAL(119, 9),  // "mergeSort"
        QT_MOC_LITERAL(129, 1),  // "p"
        QT_MOC_LITERAL(131, 1),  // "r"
        QT_MOC_LITERAL(133, 18),  // "on_FindBut_clicked"
        QT_MOC_LITERAL(152, 5),  // "merge"
        QT_MOC_LITERAL(158, 1),  // "q"
        QT_MOC_LITERAL(160, 23),  // "on_MergeSortBut_clicked"
        QT_MOC_LITERAL(184, 21)   // "on_STLSortBut_clicked"
    },
    "MainWindow",
    "on_GenerateBut_clicked",
    "",
    "on_LinearSearchBut_clicked",
    "on_BinarySearchBut_clicked",
    "LinearSearch",
    "Num",
    "BinarySearch",
    "mergeSort",
    "p",
    "r",
    "on_FindBut_clicked",
    "merge",
    "q",
    "on_MergeSortBut_clicked",
    "on_STLSortBut_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   74,    2, 0x08,    1 /* Private */,
       3,    0,   75,    2, 0x08,    2 /* Private */,
       4,    0,   76,    2, 0x08,    3 /* Private */,
       5,    1,   77,    2, 0x08,    4 /* Private */,
       7,    1,   80,    2, 0x08,    6 /* Private */,
       8,    2,   83,    2, 0x08,    8 /* Private */,
      11,    0,   88,    2, 0x08,   11 /* Private */,
      12,    3,   89,    2, 0x08,   12 /* Private */,
      14,    0,   96,    2, 0x08,   16 /* Private */,
      15,    0,   97,    2, 0x08,   17 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Int, QMetaType::Int,    6,
    QMetaType::Int, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    9,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,    9,   13,   10,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_GenerateBut_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_LinearSearchBut_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_BinarySearchBut_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'LinearSearch'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'BinarySearch'
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'mergeSort'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_FindBut_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'merge'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_MergeSortBut_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_STLSortBut_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_GenerateBut_clicked(); break;
        case 1: _t->on_LinearSearchBut_clicked(); break;
        case 2: _t->on_BinarySearchBut_clicked(); break;
        case 3: { int _r = _t->LinearSearch((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 4: { int _r = _t->BinarySearch((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 5: _t->mergeSort((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 6: _t->on_FindBut_clicked(); break;
        case 7: _t->merge((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3]))); break;
        case 8: _t->on_MergeSortBut_clicked(); break;
        case 9: _t->on_STLSortBut_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
